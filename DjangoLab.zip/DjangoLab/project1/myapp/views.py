from django.shortcuts import render
from django.http import response
from .models import Car

# Create your views here.

def addcar(request):
	if request.method=="POST":
		cname=request.POST.get("cname")
		cprice=request.POST.get("cprice")
		ccompany=request.POST.get("ccompany")
		ccolor=request.POST.get("ccolor")

		query=Car(cname=cname,cprice=cprice,ccompany=ccompany,ccolor=ccolor)
		query.save()
	else:
		pass

	return render(request,'add.html')

def home(request):
	return render(request,'home.html')

def display(request):
	data=Car.objects.all()
	return render(request,'display.html',{'data' : data})
