from django.db import models

# Create your models here.

class Car(models.Model):
	cname=models.CharField(max_length=50)
	cprice=models.IntegerField(max_length=40)
	ccompany=models.CharField(max_length=30)
	ccolor=models.CharField(max_length=50)

def __str__(self):
	return self.cname+" "+self.cprice+" "+self.ccompany+" "+self.ccolor
